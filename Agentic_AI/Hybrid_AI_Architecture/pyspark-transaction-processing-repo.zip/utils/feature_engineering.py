
from pyspark.sql.functions import hour, col, when

def build_features(df, config):

    threshold = config["high_value_threshold"]

    df = df.withColumn(
        "transaction_hour",
        hour(col("transaction_timestamp"))
    )

    df = df.withColumn(
        "is_high_value",
        when(col("transaction_amount") > threshold, 1).otherwise(0)
    )

    df = df.withColumn(
        "is_night_transaction",
        when(col("transaction_hour") < 6, 1).otherwise(0)
    )

    return df
