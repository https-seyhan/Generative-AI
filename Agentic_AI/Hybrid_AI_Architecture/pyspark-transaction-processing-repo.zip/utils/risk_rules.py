
from pyspark.sql.functions import col, when

def apply_risk_rules(df):

    df = df.withColumn(
        "high_risk_country_flag",
        when(col("country").isin("IR","KP","SY"),1).otherwise(0)
    )

    df = df.withColumn(
        "suspicious_transaction",
        when(
            (col("is_high_value")==1) &
            (col("is_night_transaction")==1),
            1
        ).otherwise(0)
    )

    return df
