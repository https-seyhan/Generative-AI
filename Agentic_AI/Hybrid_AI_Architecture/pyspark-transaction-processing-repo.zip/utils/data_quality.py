
from pyspark.sql.functions import col

def clean_transactions(df):

    df = df.filter(col("transaction_amount").isNotNull())
    df = df.filter(col("transaction_timestamp").isNotNull())

    df = df.dropDuplicates(["transaction_id"])

    return df
