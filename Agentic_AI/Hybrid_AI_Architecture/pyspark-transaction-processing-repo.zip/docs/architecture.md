
# Transaction Processing Architecture

## Flow

Raw Transactions
→ Data Quality
→ Feature Engineering
→ Risk Rules
→ Aggregations
→ Analytics Output

## Use Cases

• Fraud detection  
• AML monitoring  
• Risk feature engineering  
• Transaction analytics  
