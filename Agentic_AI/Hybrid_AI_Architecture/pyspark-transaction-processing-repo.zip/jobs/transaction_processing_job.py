
from pyspark.sql import SparkSession
from utils.data_quality import clean_transactions
from utils.feature_engineering import build_features
from utils.risk_rules import apply_risk_rules
import yaml

spark = SparkSession.builder.appName("TransactionProcessingJob").getOrCreate()

config = yaml.safe_load(open("config/job_config.yaml"))

transactions = spark.read.parquet(config["input_path"])

clean_df = clean_transactions(transactions)
feature_df = build_features(clean_df, config)
risk_df = apply_risk_rules(feature_df)

risk_df.write.mode("overwrite").parquet(config["output_path"])
