
# PySpark Transaction Processing Pipeline

Production-style PySpark pipeline for transaction processing, feature engineering,
risk flagging, and analytics outputs.

## Architecture

Transactions → Data Quality → Feature Engineering → Risk Rules → Aggregations → Output Tables

## Run

spark-submit jobs/transaction_processing_job.py
